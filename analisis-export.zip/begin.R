install.packages("tidyverse")
install.packages("readxl")

library(tidyverse)
library(readxl)

#lectura de las bases de datos "Base/name"
base_principal <- read_csv("Bases/BasePrincipal.csv")
print("Base Principal:")
print(head(base_principal))

base_departamentos <- read_excel("Bases/Divipola.xlsx")
print("Base Departamentos:")
print(head(base_departamentos))

base_vehiculos <- read_excel("Bases/Homologaciones.xlsx")
print("Base Vehículos:")
print(head(base_vehiculos))

# Verificar problemas de análisis en los archivos Excel
problemas_departamentos <- problems(base_departamentos)
problemas_vehiculos <- problems(base_vehiculos)

if (nrow(problemas_departamentos) > 0) {
  print("Problemas en la base de datos de departamentos:")
  print(problemas_departamentos)
}

if (nrow(problemas_vehiculos) > 0) {
  print("Problemas en la base de datos de vehículos:")
  print(problemas_vehiculos)
}

if (nrow(problemas_departamentos) == 0 && nrow(problemas_vehiculos) == 0) {
  print("Archivos cargados correctamente.")
} else {
  print("Existen problemas en los archivos de Excel que necesitan 
        ser corregidos antes de continuar.")
}

#ver todas las columnas de las primeras filas
print("Primeras 5 filas de base_principal:")
glimpse(head(base_principal, 5))

print("Primeras 5 filas de base_departamentos:")
glimpse(head(base_departamentos, 5))

print("Primeras 5 filas de base_vehiculos:")
glimpse(head(base_vehiculos, 5))

#cambios de nombres y correccion de tipo de dato
base_departamentos <- base_departamentos %>%
  rename(cod_dep_tomador = cod_depto, zona_geografica = Geografica)%>%
  mutate(cod_dep_tomador = as.numeric(cod_dep_tomador))

#combinacion de las bases de datos en anclaje de columna numerica
base_combinada <- base_principal %>%
  left_join(base_departamentos, by = "cod_dep_tomador") %>%
  left_join(base_vehiculos, by = "cod_tarifa")

print("Base combinada:")
glimpse(head(base_combinada, 5))

#extraccion de la fecha apartir de Fexp 
base_combinada <- base_combinada %>%
  mutate(FEXP = as.character(Fexp),  
         FEXP = case_when(
           nchar(FEXP) == 8 ~ as.Date(FEXP, format = "%d%m%Y"),  
           nchar(FEXP) == 7 ~ as.Date(paste0("0", FEXP), format = "%d%m%Y"),  
           TRUE ~ NA_Date_  
         ),
         ano_exp = year(FEXP),  
         mes_exp = month(FEXP))  

# Obtener la cantidad de tipos de pólizas
tipos_polizas <- base_combinada %>%
  summarise(num_tipos_polizas = n_distinct(num_interno_poliza))

# Obtener la cantidad de tipos de vehículos
tipos_vehiculos <- base_combinada %>%
  summarise(num_tipos_vehiculos = n_distinct(Tipo_Vehiculo))

# Imprimir resultados
print(tipos_polizas)
print(tipos_vehiculos)

#Tabla 1: Número de pólizas distintas expedidas por tipo de vehículo
tabla_polizas_por_vehiculo <- base_combinada %>%
  group_by(ano_exp, mes_exp, Tipo_Vehiculo) %>%
  summarise(num_polizas = n_distinct(num_interno_poliza)) %>%
  ungroup() %>%
  pivot_wider(names_from = Tipo_Vehiculo, values_from = num_polizas,
              values_fill = list(num_polizas = 0))

print(tabla_polizas_por_vehiculo)

# Tabla 2: Suma de la prima emitida en millones de pesos por zona geográfica
tabla_prima_por_zona <- base_combinada %>%
  group_by(ano_exp, mes_exp, zona_geografica) %>%
  summarise(suma_prima = sum(valor_prima) / 1e6) %>%
  ungroup() %>%
  pivot_wider(names_from = zona_geografica, values_from = suma_prima, 
              values_fill = list(suma_prima = 0))

print(tabla_prima_por_zona)
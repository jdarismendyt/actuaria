
library(tidyverse)
calificaciones <- read_csv("calificaciones.csv", col_names = FALSE)
colnames(calificaciones) <- c("Calificacion")

# Convertir la columna a numérico si es necesario y eliminar NAs
calificaciones <- calificaciones %>%
  mutate(Calificacion = as.numeric(Calificacion)) %>%
  drop_na()
print(calificaciones)

# Calcular estadísticas descriptivas
media <- mean(calificaciones$Calificacion, na.rm = TRUE)
mediana <- median(calificaciones$Calificacion, na.rm = TRUE)
percentil_25 <- quantile(calificaciones$Calificacion, 0.25, na.rm = TRUE)
percentil_75 <- quantile(calificaciones$Calificacion, 0.75, na.rm = TRUE)
percentil_90 <- quantile(calificaciones$Calificacion, 0.90, na.rm = TRUE)
desviacion_estandar <- sd(calificaciones$Calificacion, na.rm = TRUE)

resumen <- tibble(
  Media = media,
  Mediana = mediana,
  Percentil_25 = percentil_25,
  Percentil_75 = percentil_75,
  Percentil_90 = percentil_90,
  Desviacion_Estandar = desviacion_estandar
)

print(resumen)

# Histograma 
ggplot(calificaciones, aes(x = Calificacion)) +
  geom_histogram(binwidth = 5, fill = "blue", color = "black", alpha = 0.7) +
  labs(title = "Histograma de Calificaciones", x = "Calificaciones",
       y = "Frecuencia") +
  theme_minimal()

# Boxplot 
ggplot(calificaciones, aes(y = Calificacion)) +
  geom_boxplot(fill = "orange", color = "black") +
  labs(title = "Boxplot de Calificaciones", y = "Calificaciones") +
  theme_minimal()

# Diagrama de bigotes 
ggplot(calificaciones, aes(x = "", y = Calificacion)) +
  geom_violin(fill = "green", color = "black", alpha = 0.7) +
  geom_boxplot(width = 0.1, fill = "yellow", color = "black", outlier.color =
                 "red") + labs(title = "Diagrama de Bigotes de Calificaciones", 
                 y = "Calificaciones") +
                 theme_minimal()

# Calcular el número de clases y la amplitud del intervalo para el histograma
n_clases <- nclass.Sturges(calificaciones$Calificacion)
amplitud_intervalo <- (max(calificaciones$Calificacion) -
                       min(calificaciones$Calificacion)) / n_clases

# Mostrar el número de clases y la amplitud del intervalo
cat("Número de clases para el histograma:", n_clases, "\n")
cat("Amplitud del intervalo para el histograma:", round(amplitud_intervalo, 2),
    "\n")
